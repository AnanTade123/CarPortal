

function BiddingCarDetail() {
  return (
    <div>BiddingCarDetail</div>
  )
}

export default BiddingCarDetail